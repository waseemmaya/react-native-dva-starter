export const style_config = {
  PRIMARY_COLOR: '#3b3387',
  H1_SIZE: 32,
  H2_SIZE: 26,
};
