const query_test = params => {
  console.log('in query_test params: ', params);

  return 'test';
};

const Test = {
  query_test,
};

export default Test;
